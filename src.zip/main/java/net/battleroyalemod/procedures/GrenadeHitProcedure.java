package net.battleroyalemod.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.core.particles.ParticleTypes;

import net.battleroyalemod.BattleroyalemodMod;

public class GrenadeHitProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z) {
		world.addParticle(ParticleTypes.SMOKE, x, y, z, 0, 1, 0);
		BattleroyalemodMod.queueServerWork(30, () -> {
			if (world instanceof Level _level && !_level.isClientSide())
				_level.explode(null, x, (y + 1), z, 4, Level.ExplosionInteraction.TNT);
		});
	}
}
