package net.battleroyalemod.procedures;

import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.Entity;
import net.minecraft.core.BlockPos;

public class LavaGunHitEntityProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity, Entity sourceentity) {
		if (entity == null || sourceentity == null)
			return;
		double Coordvar = 0;
		double Coordvar2 = 0;
		Coordvar = -1;
		Coordvar2 = -1;
		if (!(entity == sourceentity)) {
			for (int index0 = 0; index0 < 3; index0++) {
				for (int index1 = 0; index1 < 3; index1++) {
					if ((world.getBlockState(BlockPos.containing(x + Coordvar, y, z + Coordvar2))).getBlock() == Blocks.AIR || (world.getBlockState(BlockPos.containing(x + Coordvar, y, z + Coordvar2))).getBlock() == Blocks.WATER) {
						world.setBlock(BlockPos.containing(x + Coordvar, y, z + Coordvar2), Blocks.LAVA.defaultBlockState(), 3);
					}
					Coordvar2 = Coordvar2 + 1;
				}
				Coordvar2 = -1;
				Coordvar = Coordvar + 1;
			}
		}
	}
}
