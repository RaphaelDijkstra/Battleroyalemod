
package net.battleroyalemod.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class CobwebArrowItem extends Item {
	public CobwebArrowItem() {
		super(new Item.Properties().stacksTo(64).rarity(Rarity.COMMON));
	}
}
