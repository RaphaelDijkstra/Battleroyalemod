
package net.battleroyalemod.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class RareScrapItem extends Item {
	public RareScrapItem() {
		super(new Item.Properties().stacksTo(64).rarity(Rarity.COMMON));
	}
}
