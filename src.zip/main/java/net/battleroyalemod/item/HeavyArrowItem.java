
package net.battleroyalemod.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class HeavyArrowItem extends Item {
	public HeavyArrowItem() {
		super(new Item.Properties().stacksTo(64).rarity(Rarity.COMMON));
	}
}
