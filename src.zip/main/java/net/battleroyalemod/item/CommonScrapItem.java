
package net.battleroyalemod.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class CommonScrapItem extends Item {
	public CommonScrapItem() {
		super(new Item.Properties().stacksTo(64).rarity(Rarity.COMMON));
	}
}
