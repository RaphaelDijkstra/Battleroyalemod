
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.battleroyalemod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.Block;

import net.battleroyalemod.block.entity.WeaponCrateBlockEntity;
import net.battleroyalemod.block.entity.RareCrateBlockEntity;
import net.battleroyalemod.block.entity.LegendaryCrateBlockEntity;
import net.battleroyalemod.block.entity.FoodCrateBlockEntity;
import net.battleroyalemod.block.entity.CrateBlockEntity;
import net.battleroyalemod.block.entity.CommonCrateBlockEntity;
import net.battleroyalemod.block.entity.AmmoCrateBlockEntity;
import net.battleroyalemod.BattleroyalemodMod;

public class BattleroyalemodModBlockEntities {
	public static final DeferredRegister<BlockEntityType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCK_ENTITY_TYPES, BattleroyalemodMod.MODID);
	public static final RegistryObject<BlockEntityType<?>> CRATE = register("crate", BattleroyalemodModBlocks.CRATE, CrateBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> AMMO_CRATE = register("ammo_crate", BattleroyalemodModBlocks.AMMO_CRATE, AmmoCrateBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> COMMON_CRATE = register("common_crate", BattleroyalemodModBlocks.COMMON_CRATE, CommonCrateBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> RARE_CRATE = register("rare_crate", BattleroyalemodModBlocks.RARE_CRATE, RareCrateBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> LEGENDARY_CRATE = register("legendary_crate", BattleroyalemodModBlocks.LEGENDARY_CRATE, LegendaryCrateBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> WEAPON_CRATE = register("weapon_crate", BattleroyalemodModBlocks.WEAPON_CRATE, WeaponCrateBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> FOOD_CRATE = register("food_crate", BattleroyalemodModBlocks.FOOD_CRATE, FoodCrateBlockEntity::new);

	// Start of user code block custom block entities
	// End of user code block custom block entities
	private static RegistryObject<BlockEntityType<?>> register(String registryname, RegistryObject<Block> block, BlockEntityType.BlockEntitySupplier<?> supplier) {
		return REGISTRY.register(registryname, () -> BlockEntityType.Builder.of(supplier, block.get()).build(null));
	}
}
