
/*
*	MCreator note: This file will be REGENERATED on each build.
*/
package net.battleroyalemod.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.village.VillagerTradesEvent;
import net.minecraftforge.common.BasicItemListing;

import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.npc.VillagerProfession;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.FORGE)
public class BattleroyalemodModTrades {
	@SubscribeEvent
	public static void registerTrades(VillagerTradesEvent event) {
		if (event.getType() == VillagerProfession.ARMORER) {
			event.getTrades().get(1).add(new BasicItemListing(new ItemStack(Items.EMERALD, 5),

					new ItemStack(BattleroyalemodModItems.EMERALD_ARMOR_HELMET.get()), 12, 5, 0.05f));
			event.getTrades().get(1).add(new BasicItemListing(new ItemStack(Items.EMERALD, 8),

					new ItemStack(BattleroyalemodModItems.EMERALD_ARMOR_CHESTPLATE.get()), 12, 5, 0.05f));
			event.getTrades().get(1).add(new BasicItemListing(new ItemStack(Items.EMERALD, 7),

					new ItemStack(BattleroyalemodModItems.EMERALD_ARMOR_LEGGINGS.get()), 12, 5, 0.05f));
			event.getTrades().get(1).add(new BasicItemListing(new ItemStack(Items.EMERALD, 5),

					new ItemStack(BattleroyalemodModItems.EMERALD_ARMOR_BOOTS.get()), 12, 5, 0.05f));
		}
		if (event.getType() == VillagerProfession.TOOLSMITH) {
			event.getTrades().get(1).add(new BasicItemListing(new ItemStack(Items.EMERALD),

					new ItemStack(BattleroyalemodModItems.EMERALD_SHOVEL.get()), 12, 5, 0.05f));
			event.getTrades().get(1).add(new BasicItemListing(new ItemStack(Items.EMERALD, 2),

					new ItemStack(BattleroyalemodModItems.EMERALD_PICKAXE.get()), 12, 5, 0.05f));
			event.getTrades().get(1).add(new BasicItemListing(new ItemStack(Items.EMERALD),

					new ItemStack(BattleroyalemodModItems.EMERALD_HOE.get()), 12, 5, 0.05f));
		}
		if (event.getType() == VillagerProfession.WEAPONSMITH) {
			event.getTrades().get(1).add(new BasicItemListing(new ItemStack(Items.EMERALD, 2),

					new ItemStack(BattleroyalemodModItems.EMERALD_SWORD.get()), 12, 5, 0.05f));
			event.getTrades().get(1).add(new BasicItemListing(new ItemStack(Items.EMERALD, 3),

					new ItemStack(BattleroyalemodModItems.EMERALD_AXE.get()), 12, 5, 0.05f));
		}
	}
}
