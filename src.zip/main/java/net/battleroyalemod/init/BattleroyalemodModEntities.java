
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.battleroyalemod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.common.Mod;

import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;

import net.battleroyalemod.entity.WaterGunProjectileEntity;
import net.battleroyalemod.entity.TeleportGunProjectileEntity;
import net.battleroyalemod.entity.SniperProjectileEntity;
import net.battleroyalemod.entity.PistolAmmoEntity;
import net.battleroyalemod.entity.LavaGunProjectileEntity;
import net.battleroyalemod.entity.GrenadeProjectileEntity;
import net.battleroyalemod.entity.FlamethrowerProjectileEntity;
import net.battleroyalemod.entity.CobwebGunProjectileEntity;
import net.battleroyalemod.entity.BazookaProjectileEntity;
import net.battleroyalemod.BattleroyalemodMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class BattleroyalemodModEntities {
	public static final DeferredRegister<EntityType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, BattleroyalemodMod.MODID);
	public static final RegistryObject<EntityType<BazookaProjectileEntity>> BAZOOKA_PROJECTILE = register("bazooka_projectile", EntityType.Builder.<BazookaProjectileEntity>of(BazookaProjectileEntity::new, MobCategory.MISC)
			.setCustomClientFactory(BazookaProjectileEntity::new).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final RegistryObject<EntityType<TeleportGunProjectileEntity>> TELEPORT_GUN_PROJECTILE = register("teleport_gun_projectile", EntityType.Builder.<TeleportGunProjectileEntity>of(TeleportGunProjectileEntity::new, MobCategory.MISC)
			.setCustomClientFactory(TeleportGunProjectileEntity::new).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final RegistryObject<EntityType<FlamethrowerProjectileEntity>> FLAMETHROWER_PROJECTILE = register("flamethrower_projectile", EntityType.Builder.<FlamethrowerProjectileEntity>of(FlamethrowerProjectileEntity::new, MobCategory.MISC)
			.setCustomClientFactory(FlamethrowerProjectileEntity::new).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final RegistryObject<EntityType<LavaGunProjectileEntity>> LAVA_GUN_PROJECTILE = register("lava_gun_projectile", EntityType.Builder.<LavaGunProjectileEntity>of(LavaGunProjectileEntity::new, MobCategory.MISC)
			.setCustomClientFactory(LavaGunProjectileEntity::new).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final RegistryObject<EntityType<WaterGunProjectileEntity>> WATER_GUN_PROJECTILE = register("water_gun_projectile", EntityType.Builder.<WaterGunProjectileEntity>of(WaterGunProjectileEntity::new, MobCategory.MISC)
			.setCustomClientFactory(WaterGunProjectileEntity::new).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final RegistryObject<EntityType<CobwebGunProjectileEntity>> COBWEB_GUN_PROJECTILE = register("cobweb_gun_projectile", EntityType.Builder.<CobwebGunProjectileEntity>of(CobwebGunProjectileEntity::new, MobCategory.MISC)
			.setCustomClientFactory(CobwebGunProjectileEntity::new).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final RegistryObject<EntityType<SniperProjectileEntity>> SNIPER_PROJECTILE = register("sniper_projectile", EntityType.Builder.<SniperProjectileEntity>of(SniperProjectileEntity::new, MobCategory.MISC)
			.setCustomClientFactory(SniperProjectileEntity::new).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final RegistryObject<EntityType<PistolAmmoEntity>> PISTOL_AMMO = register("pistol_ammo",
			EntityType.Builder.<PistolAmmoEntity>of(PistolAmmoEntity::new, MobCategory.MISC).setCustomClientFactory(PistolAmmoEntity::new).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final RegistryObject<EntityType<GrenadeProjectileEntity>> GRENADE_PROJECTILE = register("grenade_projectile", EntityType.Builder.<GrenadeProjectileEntity>of(GrenadeProjectileEntity::new, MobCategory.MISC)
			.setCustomClientFactory(GrenadeProjectileEntity::new).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));

	// Start of user code block custom entities
	// End of user code block custom entities
	private static <T extends Entity> RegistryObject<EntityType<T>> register(String registryname, EntityType.Builder<T> entityTypeBuilder) {
		return REGISTRY.register(registryname, () -> (EntityType<T>) entityTypeBuilder.build(registryname));
	}
}
