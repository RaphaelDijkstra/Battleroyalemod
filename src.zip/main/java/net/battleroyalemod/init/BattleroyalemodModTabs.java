
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.battleroyalemod.init;

import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.core.registries.Registries;

import net.battleroyalemod.BattleroyalemodMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class BattleroyalemodModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, BattleroyalemodMod.MODID);

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.FUNCTIONAL_BLOCKS) {

			tabData.accept(BattleroyalemodModBlocks.CRATE.get().asItem());
			tabData.accept(BattleroyalemodModBlocks.AMMO_CRATE.get().asItem());
			tabData.accept(BattleroyalemodModBlocks.COMMON_CRATE.get().asItem());
			tabData.accept(BattleroyalemodModBlocks.RARE_CRATE.get().asItem());
			tabData.accept(BattleroyalemodModBlocks.LEGENDARY_CRATE.get().asItem());
			tabData.accept(BattleroyalemodModBlocks.WEAPON_CRATE.get().asItem());
			tabData.accept(BattleroyalemodModBlocks.FOOD_CRATE.get().asItem());

		} else if (tabData.getTabKey() == CreativeModeTabs.COMBAT) {

			tabData.accept(BattleroyalemodModItems.EMERALD_SWORD.get());
			tabData.accept(BattleroyalemodModItems.EMERALD_ARMOR_HELMET.get());
			tabData.accept(BattleroyalemodModItems.EMERALD_ARMOR_CHESTPLATE.get());
			tabData.accept(BattleroyalemodModItems.EMERALD_ARMOR_LEGGINGS.get());
			tabData.accept(BattleroyalemodModItems.EMERALD_ARMOR_BOOTS.get());
			tabData.accept(BattleroyalemodModItems.LAPIS_ARMOR_HELMET.get());
			tabData.accept(BattleroyalemodModItems.LAPIS_ARMOR_CHESTPLATE.get());
			tabData.accept(BattleroyalemodModItems.LAPIS_ARMOR_LEGGINGS.get());
			tabData.accept(BattleroyalemodModItems.LAPIS_ARMOR_BOOTS.get());
			tabData.accept(BattleroyalemodModItems.LAPIS_TOOLS_SWORD.get());
			tabData.accept(BattleroyalemodModItems.DIRT_ARMOR_HELMET.get());
			tabData.accept(BattleroyalemodModItems.DIRT_ARMOR_CHESTPLATE.get());
			tabData.accept(BattleroyalemodModItems.DIRT_ARMOR_LEGGINGS.get());
			tabData.accept(BattleroyalemodModItems.DIRT_ARMOR_BOOTS.get());
			tabData.accept(BattleroyalemodModItems.TELEPORT_GUN_AMMO.get());
			tabData.accept(BattleroyalemodModItems.TNT_ARROW.get());
			tabData.accept(BattleroyalemodModItems.BAZOOKA.get());
			tabData.accept(BattleroyalemodModItems.TELEPORT_GUN.get());
			tabData.accept(BattleroyalemodModItems.FLAMETHROWER.get());
			tabData.accept(BattleroyalemodModItems.LAVA_GUN.get());
			tabData.accept(BattleroyalemodModItems.WATER_GUN.get());
			tabData.accept(BattleroyalemodModItems.COBWEB_GUN.get());
			tabData.accept(BattleroyalemodModItems.SNIPER.get());
			tabData.accept(BattleroyalemodModItems.COMMON_ARMOR_HELMET.get());
			tabData.accept(BattleroyalemodModItems.COMMON_ARMOR_CHESTPLATE.get());
			tabData.accept(BattleroyalemodModItems.COMMON_ARMOR_LEGGINGS.get());
			tabData.accept(BattleroyalemodModItems.COMMON_ARMOR_BOOTS.get());
			tabData.accept(BattleroyalemodModItems.RARE_ARMOR_HELMET.get());
			tabData.accept(BattleroyalemodModItems.RARE_ARMOR_CHESTPLATE.get());
			tabData.accept(BattleroyalemodModItems.RARE_ARMOR_LEGGINGS.get());
			tabData.accept(BattleroyalemodModItems.RARE_ARMOR_BOOTS.get());
			tabData.accept(BattleroyalemodModItems.LEGENDARY_ARMOR_HELMET.get());
			tabData.accept(BattleroyalemodModItems.LEGENDARY_ARMOR_CHESTPLATE.get());
			tabData.accept(BattleroyalemodModItems.LEGENDARY_ARMOR_LEGGINGS.get());
			tabData.accept(BattleroyalemodModItems.LEGENDARY_ARMOR_BOOTS.get());
			tabData.accept(BattleroyalemodModItems.COMMON_KNIFE.get());
			tabData.accept(BattleroyalemodModItems.RARE_KNIFE.get());
			tabData.accept(BattleroyalemodModItems.LEGENDARY_KNIFE.get());
			tabData.accept(BattleroyalemodModItems.LAVA_ARROW.get());
			tabData.accept(BattleroyalemodModItems.COBWEB_ARROW.get());
			tabData.accept(BattleroyalemodModItems.WATER_ARROW.get());
			tabData.accept(BattleroyalemodModItems.PISTOL.get());
			tabData.accept(BattleroyalemodModItems.LIGHT_ARROW.get());
			tabData.accept(BattleroyalemodModItems.GRENADE.get());

		} else if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {

			tabData.accept(BattleroyalemodModItems.EMERALD_AXE.get());
			tabData.accept(BattleroyalemodModItems.EMERALD_PICKAXE.get());
			tabData.accept(BattleroyalemodModItems.EMERALD_HOE.get());
			tabData.accept(BattleroyalemodModItems.EMERALD_SHOVEL.get());
			tabData.accept(BattleroyalemodModItems.LAPIS_TOOLS_PICKAXE.get());
			tabData.accept(BattleroyalemodModItems.LAPIS_TOOLS_AXE.get());
			tabData.accept(BattleroyalemodModItems.LAPIS_TOOLS_SHOVEL.get());
			tabData.accept(BattleroyalemodModItems.LAPIS_TOOLS_HOE.get());
			tabData.accept(BattleroyalemodModItems.BOX_BREAKER.get());

		} else if (tabData.getTabKey() == CreativeModeTabs.FOOD_AND_DRINKS) {

			tabData.accept(BattleroyalemodModItems.BANDAGE.get());

		}
	}
}
