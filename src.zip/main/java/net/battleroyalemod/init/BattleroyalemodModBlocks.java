
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.battleroyalemod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import net.battleroyalemod.block.WeaponCrateBlock;
import net.battleroyalemod.block.RareCrateBlock;
import net.battleroyalemod.block.LegendaryCrateBlock;
import net.battleroyalemod.block.FoodCrateBlock;
import net.battleroyalemod.block.CrateBlock;
import net.battleroyalemod.block.CommonCrateBlock;
import net.battleroyalemod.block.AmmoCrateBlock;
import net.battleroyalemod.BattleroyalemodMod;

public class BattleroyalemodModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, BattleroyalemodMod.MODID);
	public static final RegistryObject<Block> CRATE = REGISTRY.register("crate", () -> new CrateBlock());
	public static final RegistryObject<Block> AMMO_CRATE = REGISTRY.register("ammo_crate", () -> new AmmoCrateBlock());
	public static final RegistryObject<Block> COMMON_CRATE = REGISTRY.register("common_crate", () -> new CommonCrateBlock());
	public static final RegistryObject<Block> RARE_CRATE = REGISTRY.register("rare_crate", () -> new RareCrateBlock());
	public static final RegistryObject<Block> LEGENDARY_CRATE = REGISTRY.register("legendary_crate", () -> new LegendaryCrateBlock());
	public static final RegistryObject<Block> WEAPON_CRATE = REGISTRY.register("weapon_crate", () -> new WeaponCrateBlock());
	public static final RegistryObject<Block> FOOD_CRATE = REGISTRY.register("food_crate", () -> new FoodCrateBlock());
	// Start of user code block custom blocks
	// End of user code block custom blocks
}
