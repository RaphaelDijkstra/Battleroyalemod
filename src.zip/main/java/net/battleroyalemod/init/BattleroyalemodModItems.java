
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.battleroyalemod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.battleroyalemod.item.WaterGunItem;
import net.battleroyalemod.item.WaterArrowItem;
import net.battleroyalemod.item.TntArrowItem;
import net.battleroyalemod.item.TeleportGunItem;
import net.battleroyalemod.item.TeleportGunAmmoItem;
import net.battleroyalemod.item.SniperItem;
import net.battleroyalemod.item.RareScrapItem;
import net.battleroyalemod.item.RareKnifeItem;
import net.battleroyalemod.item.RareArmorItem;
import net.battleroyalemod.item.PistolItem;
import net.battleroyalemod.item.LightArrowItem;
import net.battleroyalemod.item.LegendaryScrapItem;
import net.battleroyalemod.item.LegendaryKnifeItem;
import net.battleroyalemod.item.LegendaryArmorItem;
import net.battleroyalemod.item.LavaGunItem;
import net.battleroyalemod.item.LavaArrowItem;
import net.battleroyalemod.item.LapisToolsSwordItem;
import net.battleroyalemod.item.LapisToolsShovelItem;
import net.battleroyalemod.item.LapisToolsPickaxeItem;
import net.battleroyalemod.item.LapisToolsHoeItem;
import net.battleroyalemod.item.LapisToolsAxeItem;
import net.battleroyalemod.item.LapisArmorItem;
import net.battleroyalemod.item.HeavyArrowItem;
import net.battleroyalemod.item.GrenadeItem;
import net.battleroyalemod.item.FlamethrowerItem;
import net.battleroyalemod.item.EmeraldSwordItem;
import net.battleroyalemod.item.EmeraldShovelItem;
import net.battleroyalemod.item.EmeraldPickaxeItem;
import net.battleroyalemod.item.EmeraldHoeItem;
import net.battleroyalemod.item.EmeraldAxeItem;
import net.battleroyalemod.item.EmeraldArmorItem;
import net.battleroyalemod.item.DirtArmorItem;
import net.battleroyalemod.item.CommonScrapItem;
import net.battleroyalemod.item.CommonKnifeItem;
import net.battleroyalemod.item.CommonArmorItem;
import net.battleroyalemod.item.CobwebGunItem;
import net.battleroyalemod.item.CobwebArrowItem;
import net.battleroyalemod.item.BoxBreakerItem;
import net.battleroyalemod.item.BazookaItem;
import net.battleroyalemod.item.BandageItem;
import net.battleroyalemod.BattleroyalemodMod;

public class BattleroyalemodModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, BattleroyalemodMod.MODID);
	public static final RegistryObject<Item> EMERALD_SWORD = REGISTRY.register("emerald_sword", () -> new EmeraldSwordItem());
	public static final RegistryObject<Item> EMERALD_AXE = REGISTRY.register("emerald_axe", () -> new EmeraldAxeItem());
	public static final RegistryObject<Item> EMERALD_PICKAXE = REGISTRY.register("emerald_pickaxe", () -> new EmeraldPickaxeItem());
	public static final RegistryObject<Item> EMERALD_HOE = REGISTRY.register("emerald_hoe", () -> new EmeraldHoeItem());
	public static final RegistryObject<Item> EMERALD_SHOVEL = REGISTRY.register("emerald_shovel", () -> new EmeraldShovelItem());
	public static final RegistryObject<Item> EMERALD_ARMOR_HELMET = REGISTRY.register("emerald_armor_helmet", () -> new EmeraldArmorItem.Helmet());
	public static final RegistryObject<Item> EMERALD_ARMOR_CHESTPLATE = REGISTRY.register("emerald_armor_chestplate", () -> new EmeraldArmorItem.Chestplate());
	public static final RegistryObject<Item> EMERALD_ARMOR_LEGGINGS = REGISTRY.register("emerald_armor_leggings", () -> new EmeraldArmorItem.Leggings());
	public static final RegistryObject<Item> EMERALD_ARMOR_BOOTS = REGISTRY.register("emerald_armor_boots", () -> new EmeraldArmorItem.Boots());
	public static final RegistryObject<Item> LAPIS_ARMOR_HELMET = REGISTRY.register("lapis_armor_helmet", () -> new LapisArmorItem.Helmet());
	public static final RegistryObject<Item> LAPIS_ARMOR_CHESTPLATE = REGISTRY.register("lapis_armor_chestplate", () -> new LapisArmorItem.Chestplate());
	public static final RegistryObject<Item> LAPIS_ARMOR_LEGGINGS = REGISTRY.register("lapis_armor_leggings", () -> new LapisArmorItem.Leggings());
	public static final RegistryObject<Item> LAPIS_ARMOR_BOOTS = REGISTRY.register("lapis_armor_boots", () -> new LapisArmorItem.Boots());
	public static final RegistryObject<Item> LAPIS_TOOLS_PICKAXE = REGISTRY.register("lapis_tools_pickaxe", () -> new LapisToolsPickaxeItem());
	public static final RegistryObject<Item> LAPIS_TOOLS_AXE = REGISTRY.register("lapis_tools_axe", () -> new LapisToolsAxeItem());
	public static final RegistryObject<Item> LAPIS_TOOLS_SWORD = REGISTRY.register("lapis_tools_sword", () -> new LapisToolsSwordItem());
	public static final RegistryObject<Item> LAPIS_TOOLS_SHOVEL = REGISTRY.register("lapis_tools_shovel", () -> new LapisToolsShovelItem());
	public static final RegistryObject<Item> LAPIS_TOOLS_HOE = REGISTRY.register("lapis_tools_hoe", () -> new LapisToolsHoeItem());
	public static final RegistryObject<Item> DIRT_ARMOR_HELMET = REGISTRY.register("dirt_armor_helmet", () -> new DirtArmorItem.Helmet());
	public static final RegistryObject<Item> DIRT_ARMOR_CHESTPLATE = REGISTRY.register("dirt_armor_chestplate", () -> new DirtArmorItem.Chestplate());
	public static final RegistryObject<Item> DIRT_ARMOR_LEGGINGS = REGISTRY.register("dirt_armor_leggings", () -> new DirtArmorItem.Leggings());
	public static final RegistryObject<Item> DIRT_ARMOR_BOOTS = REGISTRY.register("dirt_armor_boots", () -> new DirtArmorItem.Boots());
	public static final RegistryObject<Item> TELEPORT_GUN_AMMO = REGISTRY.register("teleport_gun_ammo", () -> new TeleportGunAmmoItem());
	public static final RegistryObject<Item> TNT_ARROW = REGISTRY.register("tnt_arrow", () -> new TntArrowItem());
	public static final RegistryObject<Item> BAZOOKA = REGISTRY.register("bazooka", () -> new BazookaItem());
	public static final RegistryObject<Item> TELEPORT_GUN = REGISTRY.register("teleport_gun", () -> new TeleportGunItem());
	public static final RegistryObject<Item> FLAMETHROWER = REGISTRY.register("flamethrower", () -> new FlamethrowerItem());
	public static final RegistryObject<Item> LAVA_GUN = REGISTRY.register("lava_gun", () -> new LavaGunItem());
	public static final RegistryObject<Item> WATER_GUN = REGISTRY.register("water_gun", () -> new WaterGunItem());
	public static final RegistryObject<Item> COBWEB_GUN = REGISTRY.register("cobweb_gun", () -> new CobwebGunItem());
	public static final RegistryObject<Item> SNIPER = REGISTRY.register("sniper", () -> new SniperItem());
	public static final RegistryObject<Item> COMMON_ARMOR_HELMET = REGISTRY.register("common_armor_helmet", () -> new CommonArmorItem.Helmet());
	public static final RegistryObject<Item> COMMON_ARMOR_CHESTPLATE = REGISTRY.register("common_armor_chestplate", () -> new CommonArmorItem.Chestplate());
	public static final RegistryObject<Item> COMMON_ARMOR_LEGGINGS = REGISTRY.register("common_armor_leggings", () -> new CommonArmorItem.Leggings());
	public static final RegistryObject<Item> COMMON_ARMOR_BOOTS = REGISTRY.register("common_armor_boots", () -> new CommonArmorItem.Boots());
	public static final RegistryObject<Item> RARE_ARMOR_HELMET = REGISTRY.register("rare_armor_helmet", () -> new RareArmorItem.Helmet());
	public static final RegistryObject<Item> RARE_ARMOR_CHESTPLATE = REGISTRY.register("rare_armor_chestplate", () -> new RareArmorItem.Chestplate());
	public static final RegistryObject<Item> RARE_ARMOR_LEGGINGS = REGISTRY.register("rare_armor_leggings", () -> new RareArmorItem.Leggings());
	public static final RegistryObject<Item> RARE_ARMOR_BOOTS = REGISTRY.register("rare_armor_boots", () -> new RareArmorItem.Boots());
	public static final RegistryObject<Item> LEGENDARY_ARMOR_HELMET = REGISTRY.register("legendary_armor_helmet", () -> new LegendaryArmorItem.Helmet());
	public static final RegistryObject<Item> LEGENDARY_ARMOR_CHESTPLATE = REGISTRY.register("legendary_armor_chestplate", () -> new LegendaryArmorItem.Chestplate());
	public static final RegistryObject<Item> LEGENDARY_ARMOR_LEGGINGS = REGISTRY.register("legendary_armor_leggings", () -> new LegendaryArmorItem.Leggings());
	public static final RegistryObject<Item> LEGENDARY_ARMOR_BOOTS = REGISTRY.register("legendary_armor_boots", () -> new LegendaryArmorItem.Boots());
	public static final RegistryObject<Item> BOX_BREAKER = REGISTRY.register("box_breaker", () -> new BoxBreakerItem());
	public static final RegistryObject<Item> COMMON_KNIFE = REGISTRY.register("common_knife", () -> new CommonKnifeItem());
	public static final RegistryObject<Item> RARE_KNIFE = REGISTRY.register("rare_knife", () -> new RareKnifeItem());
	public static final RegistryObject<Item> LEGENDARY_KNIFE = REGISTRY.register("legendary_knife", () -> new LegendaryKnifeItem());
	public static final RegistryObject<Item> COMMON_SCRAP = REGISTRY.register("common_scrap", () -> new CommonScrapItem());
	public static final RegistryObject<Item> RARE_SCRAP = REGISTRY.register("rare_scrap", () -> new RareScrapItem());
	public static final RegistryObject<Item> LEGENDARY_SCRAP = REGISTRY.register("legendary_scrap", () -> new LegendaryScrapItem());
	public static final RegistryObject<Item> LAVA_ARROW = REGISTRY.register("lava_arrow", () -> new LavaArrowItem());
	public static final RegistryObject<Item> COBWEB_ARROW = REGISTRY.register("cobweb_arrow", () -> new CobwebArrowItem());
	public static final RegistryObject<Item> WATER_ARROW = REGISTRY.register("water_arrow", () -> new WaterArrowItem());
	public static final RegistryObject<Item> CRATE = block(BattleroyalemodModBlocks.CRATE);
	public static final RegistryObject<Item> AMMO_CRATE = block(BattleroyalemodModBlocks.AMMO_CRATE);
	public static final RegistryObject<Item> COMMON_CRATE = block(BattleroyalemodModBlocks.COMMON_CRATE);
	public static final RegistryObject<Item> RARE_CRATE = block(BattleroyalemodModBlocks.RARE_CRATE);
	public static final RegistryObject<Item> LEGENDARY_CRATE = block(BattleroyalemodModBlocks.LEGENDARY_CRATE);
	public static final RegistryObject<Item> WEAPON_CRATE = block(BattleroyalemodModBlocks.WEAPON_CRATE);
	public static final RegistryObject<Item> FOOD_CRATE = block(BattleroyalemodModBlocks.FOOD_CRATE);
	public static final RegistryObject<Item> HEAVY_ARROW = REGISTRY.register("heavy_arrow", () -> new HeavyArrowItem());
	public static final RegistryObject<Item> BANDAGE = REGISTRY.register("bandage", () -> new BandageItem());
	public static final RegistryObject<Item> PISTOL = REGISTRY.register("pistol", () -> new PistolItem());
	public static final RegistryObject<Item> LIGHT_ARROW = REGISTRY.register("light_arrow", () -> new LightArrowItem());
	public static final RegistryObject<Item> GRENADE = REGISTRY.register("grenade", () -> new GrenadeItem());

	// Start of user code block custom items
	// End of user code block custom items
	private static RegistryObject<Item> block(RegistryObject<Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}
}
